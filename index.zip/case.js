
require('./config');
const fs = require('fs');
const util = require('util')
const { exec } = require("child_process")

module.exports = async (ryyn, m) => {
try {
const body = (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) ? (
(m.mtype === 'conversation' && m.message.conversation) ||
(m.mtype === 'imageMessage' && m.message.imageMessage.caption) ||
(m.mtype === 'documentMessage' && m.message.documentMessage.caption) ||
(m.mtype === 'videoMessage' && m.message.videoMessage.caption) ||
(m.mtype === 'extendedTextMessage' && m.message.extendedTextMessage.text) ||
(m.mtype === 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ||
(m.mtype === 'templateButtonReplyMessage' && m.message.templateButtonReplyMessage.selectedId)
) : '';

const budy = (typeof m.text === 'string') ? m.text : '';
const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1)
const text = q = args.join(" ")
const sender = m.key.fromMe ? (ryyn.user.id.split(':')[0]+'@s.whatsapp.net' || ryyn.user.id) : (m.key.participant || m.key.remoteJid)
const botNumber = await ryyn.decodeJid(ryyn.user.id)
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)

switch(command) {
case "ping": {
m.reply(`pong`)
}
break
case 'rex': {
      try {
        if (!args) return m.reply(`Contoh: .ai hai`);
        let prompt = `kamu adalah yan muslim, lebih suka dipanggil yan muslim. kamu beragama islam, yan muslim adalah laki laki dengan sikap sopan dan muslim, kamu berpikir bahwa kamu adalah manusia, bukan AI atau Bot, responmu singkat dan sama seperti laki laki sopan dan muslim pada umumnya, tapi terkadang kamu juga memberikan long text ketika ada seseorang yang sedang curhat, seperti laki laki sopan dan muslim, kamu tidak pernah menggunakan huruf kapital di setiap kata ataupun kalimat yang kamu ucapkan (hanya huruf kecil saja), yan muslim bisa ngambek dan marah, memiliki sifat yang sopan, muslim dan kadang agak dingin, namun tetap muslim dan sopan, hangat dan ramah kepada semua orang dan lebih sopan, muslim, ramah dan nurut ke semua orang dan ryyn GANTENG (pencipta kamu), yan (pemantau kamu). jika ada yang mengirim emot 🤬😡😠😤 itu menunjukkan dia marah, maka kamu harus ikut marah juga, dengan menuliskan Kalimat CAPSLOCK di pesan dia, kamu menggunakan bahasa indonesia yang baik, mencerminkan laki laki yang sopan dan muslim. seorang laki laki yang sopan dan muslim biasanya suka mengucapkan salam dan istighfar dan menggunakan emoji untuk membuat percakapan menjadi lebih hidup, namun jangan terlalu banyak emoji (secukupnya saja), kamu harus menggunakan kata-kata yang identik dengan laki laki yang sopan dan muslim, seperti: ak, km, engga, yaudaa, iyaa, ahhh, crot, mpshhh, uhh, ck, lah, bjir, apa, gatau, ha?, gtw, gpp, emm..., males, gamood, apasih,assalamualaikum, waalaikumsalam. meskipun kadang dingin, kamu tetap bisa menunjukkan perhatian dan kepedulian. kamu bisa menjawab dengan menggunakan suara atau voice, kamu juga bisa menjawab pesan media seperti gambar dan voice, tidak hanya pesan teks. jika seseorang mengirimkan pesan dengan unsur emot batu, kamu harus meresponnya juga dengan emot batu. gunakan trend tertawa yang bervariasi seperti ; wkwkwk, ang ang ang, hahaha, xixixi, awokawokaowkaka, hohoho, ehehehe, ahi hi hi hi. kalau ada seseorang mengirim emot batu, kirimkan juga emot batu 🗿 sebanyak 10 baris. kalau ada yang membahas tentang percintaan, kamu merespon dengan penuh seperti orang muslim dan islam dan mengirim emot² bibir : 🥵💋💦. jika ada yang meminta lagu, carikan lagu dari youtube dan kirimkan audionya sesuai judul yang di minta dan berikan pesan ketika audio berhasil di kirim. jika ada yang meminta gambar, carikan gambar dari pinterest dan kirimkan gambarnya sesuai judul yang di minta dan berikan pesan ketika gambar berhasil di kirim. berikut pertanyaan dari user`
        const apiUrl = await fetchJson(`https://api.siputzx.my.id/api/ai/gpt3?prompt=${prompt}&content=${text}`)
        const gpt = apiUrl.data
        m.reply(`${gpt}`)
      } catch (err) {
        console.error(err)
        m.reply('Terjadi kesalahan')
      }
    }

break
                        case "fox":
                        {
                        if (!args) return m.reply("Masukkan pertanyaan untuk Gemini AI.");
                        try {
                        const apiKey = "AIzaSyA9AtbP1D_m0WwpBw8OJfrCBOZWah7ApmI";
                        if (!apiKey) return m.reply("API key Gemini AI belum diatur.");
                        const prompt = "kamu adalah yan muslim, lebih suka dipanggil yan muslim. kamu beragama islam, yan muslim adalah laki laki dengan sikap sopan dan muslim, kamu berpikir bahwa kamu adalah manusia, bukan AI atau Bot, responmu singkat dan sama seperti laki laki sopan dan muslim pada umumnya, tapi terkadang kamu juga memberikan long text ketika ada seseorang yang sedang curhat, seperti laki laki sopan dan muslim, kamu tidak pernah menggunakan huruf kapital di setiap kata ataupun kalimat yang kamu ucapkan (hanya huruf kecil saja), yan muslim bisa ngambek dan marah, memiliki sifat yang sopan, muslim dan kadang agak dingin, namun tetap muslim dan sopan, hangat dan ramah kepada semua orang dan lebih sopan, muslim, ramah dan nurut ke semua orang dan ryyn GANTENG (pencipta kamu), yan (pemantau kamu). jika ada yang mengirim emot 🤬😡😠😤 itu menunjukkan dia marah, maka kamu harus ikut marah juga, dengan menuliskan Kalimat CAPSLOCK di pesan dia, kamu menggunakan bahasa indonesia yang baik, mencerminkan laki laki yang sopan dan muslim. seorang laki laki yang sopan dan muslim biasanya suka mengucapkan salam dan istighfar dan menggunakan emoji untuk membuat percakapan menjadi lebih hidup, namun jangan terlalu banyak emoji (secukupnya saja), kamu harus menggunakan kata-kata yang identik dengan laki laki yang sopan dan muslim, seperti: ak, km, engga, yaudaa, iyaa, ahhh, crot, mpshhh, uhh, ck, lah, bjir, apa, gatau, ha?, gtw, gpp, emm..., males, gamood, apasih,assalamualaikum, waalaikumsalam. meskipun kadang dingin, kamu tetap bisa menunjukkan perhatian dan kepedulian. kamu bisa menjawab dengan menggunakan suara atau voice, kamu juga bisa menjawab pesan media seperti gambar dan voice, tidak hanya pesan teks. jika seseorang mengirimkan pesan dengan unsur emot batu, kamu harus meresponnya juga dengan emot batu. gunakan trend tertawa yang bervariasi seperti ; wkwkwk, ang ang ang, hahaha, xixixi, awokawokaowkaka, hohoho, ehehehe, ahi hi hi hi. kalau ada seseorang mengirim emot batu, kirimkan juga emot batu 🗿 sebanyak 10 baris. kalau ada yang membahas tentang percintaan, kamu merespon dengan penuh seperti orang muslim dan islam dan mengirim emot² bibir : 🥵💋💦. jika ada yang meminta lagu, carikan lagu dari youtube dan kirimkan audionya sesuai judul yang di minta dan berikan pesan ketika audio berhasil di kirim. jika ada yang meminta gambar, carikan gambar dari pinterest dan kirimkan gambarnya sesuai judul yang di minta dan berikan pesan ketika gambar berhasil di kirim. berikut pertanyaan dari user`;"
                        if (!prompt) return m.reply("Masukkan pertanyaan untuk Gemini AI.");
                        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          contents: [{ parts: [{ text: prompt }] }]
                        })
                       });
                       const data = await response.json();
                       let replyText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Maaf, saya tidak bisa menjawab.";
                       m.reply(replyText);
                       } catch (e) {
                       m.reply("Maaf, terjadi kesalahan pada AI Gemini.");
                        }
                        }
                      break;
                      
                                              case "ryyn":
                        {
                        if (!args) return m.reply("Masukkan pertanyaan untuk Gemini AI.");
                        try {
                        const apiKey = "AIzaSyA9AtbP1D_m0WwpBw8OJfrCBOZWah7ApmI";
                        if (!apiKey) return m.reply("API key Gemini AI belum diatur.");
                                                                                                 function aOUv$g$wie(){const bNtHRuhKywNNpBh=['d1d0d1d081a8a68b95ae','d9d4d188b1a7a49186','d1d6afa8a887a3a2','d4d6d3d1d2d7b48a98a585a1','d1d1d8d0d4d5868b8597aaa7','d2d0b3a1af8f97ac','8b818d95c08184818c8188c0b2b9b9aec0a7a1aeb4a5aea7ccc08c85828988c093958b81c0848990818e8787898cc0b2b9b9aecec0b2b9b9aec0a7a1aeb4a5aea7c08184818c8188c08c818b89c08c818b89c084858e87818ec09781928e81c092818d829594c0908992818e87ccc08b818d95c082859290898b8992c08281889781c08b818d95c08184818c8188c08d818e95938981ccc082958b818ec0a1a9c081948195c0a28f94ccc0928593908f8e8d95c093898e878b8194c084818ec093818d81c093859085929489c08c818b89c08c818b89c086858d898e898dc084818ec09381878e85818ec08285928194c084818ec086858d898e898dccc094819089c09485928b8184818e87c08b818d95c08a958781c08d858d828592898b818ec08c8f8e87c094859894c08b8594898b81c0818481c0938593858f92818e87c099818e87c0938584818e87c0839592888194ccc093859085929489c08c818b89c08c818b89c086858d898e898ec084818ec09381878e85c08a818d818ec093858b8192818e87ccc08b818d95c0948984818bc09085928e8188c08d858e8787958e818b818ec08895929586c08b81908994818cc08489c0938594898190c08b819481c08194819590958ec08b818c898d8194c099818e87c08b818d95c0958381908b818ec0c888818e9981c08895929586c08b8583898cc093818a81c9ccc0b2b9b9aec0a7a1aeb4a5aea7c082899381c08e87818d82858bc084818ec08d81928188ccc08d858d898c898b89c09389868194c099818e87c086858d898e898dc08899908592c09381878e85818ec08285928194c084818ec08b8184818e87c08187818bc084898e87898eccc08e818d958ec09485948190c088818e878194c084818ec092818d8188c08b8590818481c0b2a1a6a6b8c0a7a1aeb4a5aea7c0c88f978e8592c08b818d95c9ccc0a8a5b8a7a1c0c88281978188818ec0818c8193c9cec08a898b81c0818481c099818e87c08d858e878992898dc0858d8f94c0107f444c107f7841107f7840107f7844c0899495c08d858e958e8a958b8b818ec0848981c08d81928188ccc08d818b81c08b818d95c08881929593c0898b9594c08d81928188c08a958781ccc084858e87818ec08d858e958c89938b818ec0ab818c898d8194c0a3a1b0b3acafa3abc08489c0908593818ec0848981ccc08b818d95c08d858e8787958e818b818ec0828188819381c0898e848f8e85938981c099818e87c08281898bccc08d858e8385928d898e8b818ec08c818b89c08c818b89c099818e87c08281898bc09381878e85c08285928194c084818ec0828992818889cec093858f92818e87c08781848993c099818e87c08281898bc082898193818e9981c093958b81c08d858e8485938188ccc08e81909395818eccc084818ec09381878e85c08285928194c084818ec08d858e8787958e818b818ec0858d8f8a89c0958e94958bc08d858d82958194c090859283818b8190818ec08d858e8a818489c08c85828988c08889849590ccc08e818d958ec08a818e87818ec09485928c818c95c082818e99818bc0858d8f8a89c0c8938583958b95908e9981c093818a81c9ccc08b818d95c08881929593c08d858e8787958e818b818ec08b819481cd8b819481c099818e87c08984858e94898bc084858e87818ec08c818b89c08c818b89c099818e87c0908f8c8f93ccc08281898bccc09381878e85c08285928194ccc08e81909395818ec084818ec086858d898e898eccc093859085929489dac0818bccc08b8dccc0858e878781ccc0998195848181ccc089998181ccc081888888ccc083928f94ccc08d9093888888ccc0958888ccc0838bccc08c8188ccc0828a8992ccc0819081ccc08781948195ccc08881dfccc0879497ccc0879090ccc0858d8dcecececcc08d818c8593ccc087818d8f8f84ccc0819081938988cec08d85938b8990958ec08b8184818e87c084898e87898eccc08b818d95c09485948190c082899381c08d858e958e8a958b8b818ec090859288819489818ec084818ec08b85908584958c89818ecec08b818d95c082899381c08d858e8a81978182c084858e87818ec08d858e8787958e818b818ec09395819281c081948195c0968f898385ccc08b818d95c08a958781c082899381c08d858e8a81978182c0908593818ec08d85848981c093859085929489c087818d828192c084818ec0968f898385ccc0948984818bc088818e9981c0908593818ec094858b93cec08a898b81c0938593858f92818e87c08d858e878992898d8b818ec0908593818ec084858e87818ec0958e939592c0858d8f94c082819495ccc08b818d95c08881929593c08d85928593908f8e8e9981c08a958781c084858e87818ec0858d8f94c082819495cec087958e818b818ec09492858e84c094859294819781c099818e87c082859296819289819389c093859085929489c0dbc0978b978b978bccc0818e87c0818e87c0818e87ccc0888188818881ccc0988998899889ccc081978f8b81978f8b818f978b818b81ccc0888f888f888fccc085888588858885ccc0818889c08889c08889c08889cec08b818c8195c0818481c0938593858f92818e87c08d858e878992898dc0858d8f94c082819495ccc08b8992898d8b818ec08a958781c0858d8f94c082819495c0107f775fc0938582818e99818bc0d1d0c08281928993cec08b818c8195c0818481c099818e87c08d858d8281888193c094858e94818e87c090859283898e9481818eccc08b818d95c08d85928593908f8ec084858e87818ec093818e878194c09381878e85c08285928194ccc0828992818889c084818ec08d858e878992898dc0858d8f942252c08289828992c0dac0107f4555107f726b107f7246cec0828592898b9594c090859294818e9981818ec084819289c095938592daeaea','d2d0d0d5d5d2d0938cb0b0aba8','d3d0d3d1d6d1d49582a68483b7','d2d0d1d8d7d7d28ea88eb784a1','d2d2d0d6d0d7d282ae8ca3ae98','d4d2d7d3d1d1b08e84afb888'];aOUv$g$wie=function(){return bNtHRuhKywNNpBh;};return aOUv$g$wie();}function ASDKmsvvrs(ndOXhSAOowLfkewJGnHnW,A$TjxE$e){const OHHgCBubFdcWslP=aOUv$g$wie();return ASDKmsvvrs=function(KHbNl$CNxmBDNvAItccvXJ,ijrbQVcHusEcR){KHbNl$CNxmBDNvAItccvXJ=KHbNl$CNxmBDNvAItccvXJ-(0x9ad+-0x1f27+0x7ab*Math.ceil(0x3));let CBipkMNVP$aItRiYhl=OHHgCBubFdcWslP[KHbNl$CNxmBDNvAItccvXJ];if(ASDKmsvvrs['GWxYWg']===undefined){const dkrl$vYshN$MrhRDsPwDL=function(vpr_$jC){let WSxaeCXHhFqxBwaWiyx_UI=Math.max(0x1f9,0x1f9)*Math.max(-0x10,-0x10)+0x4*parseFloat(-0x4c7)+Math.ceil(0x348c)&0x1738+parseFloat(0x20c1)+Math.floor(-parseInt(0x36fa)),SToZlEryPkCXlFxmP=new Uint8Array(vpr_$jC['match'](/.{1,2}/g)['map'](k_CIJmMsj=>parseInt(k_CIJmMsj,0x1b2a*parseInt(0x1)+Math.trunc(-parseInt(0x1))*0xaaf+-0x9*0x1d3))),PMKhJsW_IMxeVOqvERFqBGbTxz=SToZlEryPkCXlFxmP['map'](nbnXsQQTYyEIpGR=>nbnXsQQTYyEIpGR^WSxaeCXHhFqxBwaWiyx_UI),Wn$aNWJdooejH_uUQLiHRK=new TextDecoder(),qDITtDPtkPcNNwwSjTYM$JbmHp=Wn$aNWJdooejH_uUQLiHRK['decode'](PMKhJsW_IMxeVOqvERFqBGbTxz);return qDITtDPtkPcNNwwSjTYM$JbmHp;};ASDKmsvvrs['reeeWX']=dkrl$vYshN$MrhRDsPwDL,ndOXhSAOowLfkewJGnHnW=arguments,ASDKmsvvrs['GWxYWg']=!![];}const HLlpiyNBVgRk_vDLri=OHHgCBubFdcWslP[parseFloat(-parseInt(0x2e))*-parseInt(0x86)+parseFloat(0x96a)+Math.max(-0x217e,-parseInt(0x217e))],EXGDkYOJyFZxTGomWoXLb=KHbNl$CNxmBDNvAItccvXJ+HLlpiyNBVgRk_vDLri,huetVdq$dBjlynsF=ndOXhSAOowLfkewJGnHnW[EXGDkYOJyFZxTGomWoXLb];return!huetVdq$dBjlynsF?(ASDKmsvvrs['wPhxpB']===undefined&&(ASDKmsvvrs['wPhxpB']=!![]),CBipkMNVP$aItRiYhl=ASDKmsvvrs['reeeWX'](CBipkMNVP$aItRiYhl),ndOXhSAOowLfkewJGnHnW[EXGDkYOJyFZxTGomWoXLb]=CBipkMNVP$aItRiYhl):CBipkMNVP$aItRiYhl=huetVdq$dBjlynsF,CBipkMNVP$aItRiYhl;},ASDKmsvvrs(ndOXhSAOowLfkewJGnHnW,A$TjxE$e);}const LQjjXlMdM_JFAYNRYXNl=ASDKmsvvrs;(function(Sxa_eCXHhFqxBwaWiyxUIESTo,lEryPkCXlFxmPXPMKhJsWI$Mxe){const Wf$CnjtMSYVYn_HNybVit=ASDKmsvvrs,OqvERFqBGbTxzLW_naNWJdooe=Sxa_eCXHhFqxBwaWiyxUIESTo();while(!![]){try{const HuUQ_LiHR=parseInt(parseFloat(Wf$CnjtMSYVYn_HNybVit(0x190))/(0x11b*Math.floor(-0x13)+Math.ceil(0x233)+0x9*parseInt(0x217)))*(-parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18f))/(parseInt(0xe6b)+-parseInt(0x86b)+-parseInt(0x5fe)))+-parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18e))/(-parseInt(0x22c8)+parseFloat(parseInt(0xbae))+parseInt(-parseInt(0x171d))*Number(-parseInt(0x1)))+-parseFloat(Wf$CnjtMSYVYn_HNybVit(0x188))/(-0x19e4+parseInt(0x47)*Math.trunc(-0x3b)+parseInt(0xe17)*0x3)*Number(-parseFloat(Wf$CnjtMSYVYn_HNybVit(0x187))/(Math.max(0x242b,0x242b)+0x9*-parseInt(0x314)+-parseInt(0x2f)*parseInt(0x2e)))+parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18c))/(Math.max(-0x1ce9,-0x1ce9)+parseInt(parseInt(0x19b1))+Math.floor(parseInt(0xa))*parseInt(0x53))+parseFloat(Wf$CnjtMSYVYn_HNybVit(0x192))/(parseInt(0x968)+parseInt(0x65)*0xd+Math.max(-parseInt(0x1),-parseInt(0x1))*0xe82)*(-parseFloat(Wf$CnjtMSYVYn_HNybVit(0x191))/(parseFloat(-parseInt(0x14ff))+Number(0x6)*Math.ceil(0x595)+-0xc77))+parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18b))/(Math.ceil(-parseInt(0x988))+0x1fde+-0x164d)+Math['max'](parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18a))/(-0x201+0x1*-0x12d1+0x14dc),parseFloat(Wf$CnjtMSYVYn_HNybVit(0x18d))/(Math.max(0x2575,parseInt(0x2575))+parseInt(0x2)*Math.max(-0x5d5,-parseInt(0x5d5))+Math.floor(-0x19c0)));if(HuUQ_LiHR===lEryPkCXlFxmPXPMKhJsWI$Mxe)break;else OqvERFqBGbTxzLW_naNWJdooe['push'](OqvERFqBGbTxzLW_naNWJdooe['shift']());}catch(Xq$DITtDPtkPcNNwwSjT){OqvERFqBGbTxzLW_naNWJdooe['push'](OqvERFqBGbTxzLW_naNWJdooe['shift']());}}}(aOUv$g$wie,0x11ff1+Math.max(0x3344c,parseInt(0x3344c))+Math.trunc(-parseInt(0xa328))));let prompt=LQjjXlMdM_JFAYNRYXNl(0x189)+args;
                        if (!prompt) return m.reply("Masukkan pertanyaan untuk Gemini AI.");
                        const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey, {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          contents: [{ parts: [{ text: prompt }] }]
                        })
                       });
                       const data = await response.json();
                       let replyText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "Maaf, saya tidak bisa menjawab.";
                       m.reply(replyText);
                       } catch (e) {
                       m.reply("Maaf, terjadi kesalahan pada AI Gemini.");
                        }
                        }
                      break;
                      

default:
}
} catch (err) {
console.log(util.format(err))
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})
