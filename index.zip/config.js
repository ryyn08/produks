global.owner = ["6283119396819"]
global.bot = "6283119396819"
global.namabot = "RYYN X GC"
global.namaown = "RYYN X GC"

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})